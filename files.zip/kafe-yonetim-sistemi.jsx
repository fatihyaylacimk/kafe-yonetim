import { useState, useEffect } from "react";

// ─── MOCK VERİ ────────────────────────────────────────────────────────────────
const INITIAL_MENU = [
  { id: 1, category: "Kahve", name: "Espresso", price: 45, desc: "Yoğun ve aromatik", photo: "☕", campaign: "" },
  { id: 2, category: "Kahve", name: "Latte", price: 65, desc: "Sütlü kahve", photo: "🥛", campaign: "2 al 1 öde" },
  { id: 3, category: "Kahve", name: "Cappuccino", price: 60, desc: "Köpüklü kahve", photo: "☕", campaign: "" },
  { id: 4, category: "Tatlı", name: "Cheesecake", price: 75, desc: "Frambuazlı cheesecake", photo: "🍰", campaign: "" },
  { id: 5, category: "Tatlı", name: "Brownie", price: 55, desc: "Çikolatalı ıslak kek", photo: "🍫", campaign: "Bugün %20 indirim" },
  { id: 6, category: "Soğuk İçecek", name: "Limonata", price: 50, desc: "Taze sıkım", photo: "🍋", campaign: "" },
  { id: 7, category: "Soğuk İçecek", name: "Ice Latte", price: 70, desc: "Soğuk sütlü kahve", photo: "🧊", campaign: "" },
];

const INITIAL_STOCK = [
  { id: 1, name: "Kahve Çekirdeği", unit: "kg", quantity: 10, minLevel: 2 },
  { id: 2, name: "Süt", unit: "L", quantity: 20, minLevel: 5 },
  { id: 3, name: "Şeker", unit: "kg", quantity: 8, minLevel: 2 },
  { id: 4, name: "Bardak (M)", unit: "adet", quantity: 150, minLevel: 30 },
  { id: 5, name: "Tatlı Malzeme", unit: "paket", quantity: 12, minLevel: 3 },
  { id: 6, name: "Soğuk İçecek", unit: "şişe", quantity: 24, minLevel: 6 },
];

const RESERVATIONS_INIT = [
  { id: 1, name: "Ayşe Yılmaz", date: "2026-06-15", time: "14:00", people: 4, table: "Masa 3", status: "onaylı" },
  { id: 2, name: "Mehmet Kaya", date: "2026-06-15", time: "19:30", people: 2, table: "Masa 7", status: "bekliyor" },
];

const STAFF_INIT = [
  { id: 1, name: "Zeynep Demir", role: "Barista", shift: "08:00-16:00", status: "aktif", salary: 18000 },
  { id: 2, name: "Ali Çelik", role: "Garson", shift: "12:00-20:00", status: "aktif", salary: 15000 },
  { id: 3, name: "Fatma Şahin", role: "Kasiyer", shift: "09:00-17:00", status: "izinli", salary: 16000 },
];

const SALES_HISTORY = [
  { date: "2026-06-08", revenue: 2840, orders: 38 },
  { date: "2026-06-09", revenue: 3120, orders: 44 },
  { date: "2026-06-10", revenue: 2650, orders: 35 },
  { date: "2026-06-11", revenue: 3480, orders: 51 },
  { date: "2026-06-12", revenue: 4100, orders: 62 },
  { date: "2026-06-13", revenue: 3750, orders: 55 },
  { date: "2026-06-14", revenue: 3200, orders: 48 },
];

const HOURLY_DATA = [
  { hour: "08", orders: 5 }, { hour: "09", orders: 12 }, { hour: "10", orders: 18 },
  { hour: "11", orders: 14 }, { hour: "12", orders: 22 }, { hour: "13", orders: 28 },
  { hour: "14", orders: 20 }, { hour: "15", orders: 16 }, { hour: "16", orders: 19 },
  { hour: "17", orders: 24 }, { hour: "18", orders: 30 }, { hour: "19", orders: 26 },
  { hour: "20", orders: 18 }, { hour: "21", orders: 10 },
];

const LOYALTY_CUSTOMERS = [
  { id: 1, name: "Selin Arslan", phone: "0532 111 2233", points: 42, visits: 18, birthday: "1992-03-14" },
  { id: 2, name: "Burak Öztürk", phone: "0541 444 5566", points: 87, visits: 35, birthday: "1988-06-21" },
  { id: 3, name: "Nisa Koç", phone: "0555 777 8899", points: 15, visits: 7, birthday: "1995-09-05" },
];

// ─── RENK & STİL TOKENs ──────────────────────────────────────────────────────
const C = {
  bg: "#0F0E0C",
  surface: "#1A1815",
  card: "#242118",
  border: "#2E2B24",
  gold: "#C8A96E",
  goldLight: "#E8C98A",
  cream: "#F5EDD8",
  muted: "#8A8070",
  green: "#5A8A5A",
  red: "#A05050",
  blue: "#4A7FA0",
};

const styles = {
  app: {
    minHeight: "100vh",
    background: C.bg,
    color: C.cream,
    fontFamily: "'Georgia', serif",
    display: "flex",
  },
  sidebar: {
    width: 220,
    background: C.surface,
    borderRight: `1px solid ${C.border}`,
    display: "flex",
    flexDirection: "column",
    position: "fixed",
    top: 0,
    left: 0,
    height: "100vh",
    zIndex: 100,
  },
  logo: {
    padding: "24px 20px",
    borderBottom: `1px solid ${C.border}`,
    fontFamily: "'Georgia', serif",
  },
  logoMain: { fontSize: 20, fontWeight: "bold", color: C.gold, letterSpacing: 2 },
  logoSub: { fontSize: 10, color: C.muted, letterSpacing: 3, marginTop: 2 },
  nav: { flex: 1, padding: "16px 0", overflowY: "auto" },
  navItem: (active) => ({
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "10px 20px",
    cursor: "pointer",
    fontSize: 13,
    color: active ? C.gold : C.muted,
    background: active ? `${C.gold}15` : "transparent",
    borderLeft: active ? `2px solid ${C.gold}` : "2px solid transparent",
    transition: "all 0.2s",
    userSelect: "none",
  }),
  main: {
    marginLeft: 220,
    flex: 1,
    padding: "28px 32px",
    overflowY: "auto",
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: C.gold,
    marginBottom: 6,
    fontFamily: "'Georgia', serif",
  },
  pageSub: { fontSize: 13, color: C.muted, marginBottom: 28 },
  card: {
    background: C.card,
    border: `1px solid ${C.border}`,
    borderRadius: 8,
    padding: 20,
  },
  grid2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 },
  grid3: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 },
  grid4: { display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 },
  statCard: {
    background: C.card,
    border: `1px solid ${C.border}`,
    borderRadius: 8,
    padding: "18px 20px",
  },
  statVal: { fontSize: 28, fontWeight: "bold", color: C.gold },
  statLabel: { fontSize: 12, color: C.muted, marginTop: 4, letterSpacing: 1 },
  statDiff: (pos) => ({ fontSize: 12, color: pos ? C.green : C.red, marginTop: 4 }),
  table: { width: "100%", borderCollapse: "collapse" },
  th: {
    textAlign: "left",
    padding: "10px 14px",
    fontSize: 11,
    color: C.muted,
    letterSpacing: 1,
    borderBottom: `1px solid ${C.border}`,
  },
  td: {
    padding: "12px 14px",
    fontSize: 13,
    borderBottom: `1px solid ${C.border}20`,
    color: C.cream,
  },
  btn: (variant = "primary") => ({
    padding: "8px 18px",
    borderRadius: 5,
    border: "none",
    cursor: "pointer",
    fontSize: 13,
    fontFamily: "'Georgia', serif",
    background: variant === "primary" ? C.gold : variant === "danger" ? C.red : C.surface,
    color: variant === "primary" ? C.bg : C.cream,
    fontWeight: "bold",
    transition: "opacity 0.2s",
  }),
  input: {
    background: C.surface,
    border: `1px solid ${C.border}`,
    borderRadius: 5,
    padding: "8px 12px",
    color: C.cream,
    fontSize: 13,
    fontFamily: "'Georgia', serif",
    outline: "none",
    width: "100%",
    boxSizing: "border-box",
  },
  badge: (color) => ({
    display: "inline-block",
    padding: "3px 10px",
    borderRadius: 20,
    fontSize: 11,
    fontWeight: "bold",
    background: `${color}25`,
    color: color,
    letterSpacing: 0.5,
  }),
  tag: {
    display: "inline-block",
    padding: "2px 8px",
    borderRadius: 4,
    fontSize: 11,
    background: `${C.gold}20`,
    color: C.gold,
    marginRight: 4,
  },
};

// ─── BILEŞENLER ──────────────────────────────────────────────────────────────

function StatCard({ label, value, diff, icon }) {
  return (
    <div style={styles.statCard}>
      <div style={{ fontSize: 22, marginBottom: 8 }}>{icon}</div>
      <div style={styles.statVal}>{value}</div>
      <div style={styles.statLabel}>{label}</div>
      {diff && <div style={styles.statDiff(diff.startsWith("+"))}>{diff}</div>}
    </div>
  );
}

function MiniBar({ data, maxVal, color }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 60 }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div
            style={{
              width: "100%",
              height: Math.round((d.val / maxVal) * 50) + 4,
              background: color,
              borderRadius: "3px 3px 0 0",
              opacity: 0.8,
            }}
          />
          <div style={{ fontSize: 9, color: C.muted, marginTop: 2 }}>{d.label}</div>
        </div>
      ))}
    </div>
  );
}

// ─── SAYFALAR ─────────────────────────────────────────────────────────────────

function Dashboard({ orders, menu }) {
  const todayRev = orders.filter(o => o.status === "tamamlandı").reduce((s, o) => s + o.total, 0);
  const activeOrders = orders.filter(o => o.status !== "tamamlandı" && o.status !== "iptal").length;
  const weekRevs = SALES_HISTORY.map(d => ({ val: d.revenue, label: d.date.slice(5) }));
  const maxRev = Math.max(...weekRevs.map(d => d.val));
  const hourly = HOURLY_DATA.map(h => ({ val: h.orders, label: h.hour }));
  const maxH = Math.max(...hourly.map(h => h.val));
  const topItems = [...menu].sort((a, b) => (b.sales || 0) - (a.sales || 0)).slice(0, 5);

  return (
    <div>
      <div style={styles.pageTitle}>Genel Bakış</div>
      <div style={styles.pageSub}>Bugün · 14 Haziran 2026</div>
      <div style={styles.grid4}>
        <StatCard icon="💰" label="BUGÜNKÜ GELİR" value={`₺${todayRev.toLocaleString()}`} diff="+12% dün" />
        <StatCard icon="🧾" label="AKTİF SİPARİŞ" value={activeOrders} diff={null} />
        <StatCard icon="👥" label="BUGÜN MÜŞTERİ" value="48" diff="+5 dün" />
        <StatCard icon="⭐" label="SADAKAT ÜYESİ" value={LOYALTY_CUSTOMERS.length} diff={null} />
      </div>
      <div style={{ ...styles.grid2, marginTop: 20 }}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 12, letterSpacing: 1 }}>HAFTALIK GELİR</div>
          <MiniBar data={weekRevs} maxVal={maxRev} color={C.gold} />
        </div>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 12, letterSpacing: 1 }}>SAATLİK YOĞUNLUK</div>
          <MiniBar data={hourly} maxVal={maxH} color={C.blue} />
        </div>
      </div>
      <div style={{ marginTop: 20 }}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>SON SİPARİŞLER</div>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>MASA</th>
                <th style={styles.th}>ÜRÜNLER</th>
                <th style={styles.th}>TUTAR</th>
                <th style={styles.th}>DURUM</th>
              </tr>
            </thead>
            <tbody>
              {orders.slice(0, 5).map(o => (
                <tr key={o.id}>
                  <td style={styles.td}>{o.table}</td>
                  <td style={styles.td}>{o.items.map(i => i.name).join(", ")}</td>
                  <td style={styles.td}>₺{o.total}</td>
                  <td style={styles.td}>
                    <span style={styles.badge(o.status === "tamamlandı" ? C.green : o.status === "hazırlanıyor" ? C.gold : C.blue)}>
                      {o.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function DigitalMenu({ menu, setMenu }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: "", category: "Kahve", price: "", desc: "", campaign: "", photo: "☕" });
  const categories = ["Kahve", "Tatlı", "Soğuk İçecek", "Yiyecek"];
  const emojis = ["☕", "🥛", "🍰", "🍫", "🍋", "🧊", "🥗", "🍵", "🧃", "🍩"];

  const addItem = () => {
    if (!form.name || !form.price) return;
    setMenu(prev => [...prev, { ...form, id: Date.now(), price: Number(form.price) }]);
    setForm({ name: "", category: "Kahve", price: "", desc: "", campaign: "", photo: "☕" });
    setShowAdd(false);
  };

  const removeItem = (id) => setMenu(prev => prev.filter(m => m.id !== id));

  const grouped = categories.reduce((acc, cat) => {
    acc[cat] = menu.filter(m => m.category === cat);
    return acc;
  }, {});

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={styles.pageTitle}>Dijital Menü</div>
          <div style={styles.pageSub}>Müşterinin göreceği menüyü düzenle · QR kodla erişilir</div>
        </div>
        <button style={styles.btn()} onClick={() => setShowAdd(!showAdd)}>+ Ürün Ekle</button>
      </div>

      {showAdd && (
        <div style={{ ...styles.card, marginBottom: 20 }}>
          <div style={{ fontSize: 14, color: C.gold, marginBottom: 16 }}>Yeni Ürün</div>
          <div style={styles.grid2}>
            <div>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>ÜRÜN ADI</label>
              <input style={styles.input} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>KATEGORİ</label>
              <select style={styles.input} value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                {categories.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>FİYAT (₺)</label>
              <input style={styles.input} type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>KAMPANYA</label>
              <input style={styles.input} value={form.campaign} onChange={e => setForm({ ...form, campaign: e.target.value })} placeholder="Örn: 2 al 1 öde" />
            </div>
          </div>
          <div style={{ marginTop: 12 }}>
            <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>AÇIKLAMA</label>
            <input style={styles.input} value={form.desc} onChange={e => setForm({ ...form, desc: e.target.value })} />
          </div>
          <div style={{ marginTop: 12 }}>
            <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 8 }}>İKON</label>
            <div style={{ display: "flex", gap: 8 }}>
              {emojis.map(e => (
                <span key={e} onClick={() => setForm({ ...form, photo: e })}
                  style={{ fontSize: 22, cursor: "pointer", padding: 4, borderRadius: 6, background: form.photo === e ? `${C.gold}30` : "transparent" }}>
                  {e}
                </span>
              ))}
            </div>
          </div>
          <div style={{ marginTop: 16, display: "flex", gap: 10 }}>
            <button style={styles.btn()} onClick={addItem}>Kaydet</button>
            <button style={styles.btn("ghost")} onClick={() => setShowAdd(false)}>İptal</button>
          </div>
        </div>
      )}

      {Object.entries(grouped).map(([cat, items]) => items.length > 0 && (
        <div key={cat} style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: C.muted, letterSpacing: 2, marginBottom: 12 }}>{cat.toUpperCase()}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
            {items.map(item => (
              <div key={item.id} style={{ ...styles.card, position: "relative" }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>{item.photo}</div>
                <div style={{ fontSize: 15, fontWeight: "bold", color: C.cream }}>{item.name}</div>
                <div style={{ fontSize: 12, color: C.muted, margin: "4px 0" }}>{item.desc}</div>
                <div style={{ fontSize: 18, color: C.gold, fontWeight: "bold" }}>₺{item.price}</div>
                {item.campaign && <div style={{ ...styles.tag, marginTop: 6, display: "block" }}>🏷 {item.campaign}</div>}
                <button onClick={() => removeItem(item.id)}
                  style={{ position: "absolute", top: 10, right: 10, background: "none", border: "none", color: C.muted, cursor: "pointer", fontSize: 16 }}>
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function OrderSystem({ orders, setOrders, menu }) {
  const tables = ["Masa 1", "Masa 2", "Masa 3", "Masa 4", "Masa 5", "Masa 6", "Masa 7", "Masa 8", "Paket"];
  const [selTable, setSelTable] = useState("Masa 1");
  const [selItems, setSelItems] = useState([]);

  const addToOrder = (item) => {
    setSelItems(prev => {
      const ex = prev.find(i => i.id === item.id);
      return ex ? prev.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i) : [...prev, { ...item, qty: 1 }];
    });
  };

  const submitOrder = () => {
    if (!selItems.length) return;
    const total = selItems.reduce((s, i) => s + i.price * i.qty, 0);
    setOrders(prev => [{
      id: Date.now(), table: selTable, items: selItems,
      total, status: "bekliyor", time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })
    }, ...prev]);
    setSelItems([]);
  };

  const updateStatus = (id, status) => setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));

  const statusFlow = { "bekliyor": "hazırlanıyor", "hazırlanıyor": "tamamlandı" };
  const statusColor = { "bekliyor": C.blue, "hazırlanıyor": C.gold, "tamamlandı": C.green, "iptal": C.red };

  return (
    <div>
      <div style={styles.pageTitle}>Sipariş Takip</div>
      <div style={styles.pageSub}>Yeni sipariş al · Mutfağa ilet · Tamamla</div>
      <div style={styles.grid2}>
        <div>
          <div style={styles.card}>
            <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>YENİ SİPARİŞ</div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>MASA</label>
              <select style={styles.input} value={selTable} onChange={e => setSelTable(e.target.value)}>
                {tables.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div style={{ fontSize: 11, color: C.muted, marginBottom: 8, letterSpacing: 1 }}>ÜRÜNLER</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 14 }}>
              {menu.map(item => (
                <button key={item.id} onClick={() => addToOrder(item)}
                  style={{ ...styles.btn("ghost"), padding: "6px 12px", fontSize: 12 }}>
                  {item.photo} {item.name} ₺{item.price}
                </button>
              ))}
            </div>
            {selItems.length > 0 && (
              <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 12, marginBottom: 12 }}>
                {selItems.map(i => (
                  <div key={i.id} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 13 }}>
                    <span>{i.photo} {i.name} ×{i.qty}</span>
                    <span style={{ color: C.gold }}>₺{i.price * i.qty}</span>
                  </div>
                ))}
                <div style={{ display: "flex", justifyContent: "space-between", fontWeight: "bold", borderTop: `1px solid ${C.border}`, paddingTop: 8, marginTop: 4 }}>
                  <span>Toplam</span>
                  <span style={{ color: C.gold }}>₺{selItems.reduce((s, i) => s + i.price * i.qty, 0)}</span>
                </div>
              </div>
            )}
            <button style={styles.btn()} onClick={submitOrder}>Siparişi Gönder →</button>
          </div>
        </div>
        <div>
          <div style={styles.card}>
            <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>AKTİF SİPARİŞLER</div>
            {orders.filter(o => o.status !== "tamamlandı" && o.status !== "iptal").map(o => (
              <div key={o.id} style={{ borderBottom: `1px solid ${C.border}`, paddingBottom: 12, marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontWeight: "bold" }}>{o.table}</span>
                  <span style={{ fontSize: 12, color: C.muted }}>{o.time}</span>
                </div>
                <div style={{ fontSize: 12, color: C.muted, marginBottom: 8 }}>
                  {o.items.map(i => `${i.name}×${i.qty}`).join(" · ")} · ₺{o.total}
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <span style={styles.badge(statusColor[o.status])}>{o.status}</span>
                  {statusFlow[o.status] && (
                    <button style={{ ...styles.btn(), padding: "3px 12px", fontSize: 11 }}
                      onClick={() => updateStatus(o.id, statusFlow[o.status])}>
                      {o.status === "bekliyor" ? "Hazırlanıyor →" : "Tamamlandı ✓"}
                    </button>
                  )}
                  <button style={{ ...styles.btn("danger"), padding: "3px 12px", fontSize: 11 }}
                    onClick={() => updateStatus(o.id, "iptal")}>İptal</button>
                </div>
              </div>
            ))}
            {orders.filter(o => o.status !== "tamamlandı" && o.status !== "iptal").length === 0 && (
              <div style={{ color: C.muted, fontSize: 13 }}>Aktif sipariş yok.</div>
            )}
          </div>
        </div>
      </div>
      <div style={{ marginTop: 20 }}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>TAMAMLANAN SİPARİŞLER</div>
          <table style={styles.table}>
            <thead><tr>
              <th style={styles.th}>MASA</th><th style={styles.th}>ÜRÜNLER</th>
              <th style={styles.th}>TUTAR</th><th style={styles.th}>SAAT</th><th style={styles.th}>DURUM</th>
            </tr></thead>
            <tbody>
              {orders.filter(o => o.status === "tamamlandı" || o.status === "iptal").map(o => (
                <tr key={o.id}>
                  <td style={styles.td}>{o.table}</td>
                  <td style={styles.td}>{o.items.map(i => i.name).join(", ")}</td>
                  <td style={styles.td}>₺{o.total}</td>
                  <td style={styles.td}>{o.time}</td>
                  <td style={styles.td}><span style={styles.badge(statusColor[o.status])}>{o.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StockSystem({ stock, setStock }) {
  const [form, setForm] = useState({ name: "", unit: "kg", quantity: "", minLevel: "" });
  const [editing, setEditing] = useState(null);

  const saveEdit = (id) => {
    setStock(prev => prev.map(s => s.id === id ? { ...s, quantity: Number(editing.quantity) } : s));
    setEditing(null);
  };

  const addStock = () => {
    if (!form.name || !form.quantity) return;
    setStock(prev => [...prev, { id: Date.now(), ...form, quantity: Number(form.quantity), minLevel: Number(form.minLevel) }]);
    setForm({ name: "", unit: "kg", quantity: "", minLevel: "" });
  };

  return (
    <div>
      <div style={styles.pageTitle}>Stok Takip</div>
      <div style={styles.pageSub}>Malzeme durumu · Otomatik düşüm · Düşük stok uyarısı</div>

      <div style={styles.grid2}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>STOK DURUMU</div>
          <table style={styles.table}>
            <thead><tr>
              <th style={styles.th}>MALZEMİ</th><th style={styles.th}>MİKTAR</th>
              <th style={styles.th}>BİRİM</th><th style={styles.th}>DURUM</th><th style={styles.th}>İŞLEM</th>
            </tr></thead>
            <tbody>
              {stock.map(s => {
                const low = s.quantity <= s.minLevel;
                return (
                  <tr key={s.id}>
                    <td style={styles.td}>{s.name}</td>
                    <td style={styles.td}>
                      {editing?.id === s.id ? (
                        <input style={{ ...styles.input, width: 80 }} type="number" value={editing.quantity}
                          onChange={e => setEditing({ ...editing, quantity: e.target.value })} />
                      ) : s.quantity}
                    </td>
                    <td style={styles.td}>{s.unit}</td>
                    <td style={styles.td}>
                      <span style={styles.badge(low ? C.red : C.green)}>{low ? "⚠ Düşük" : "✓ Yeterli"}</span>
                    </td>
                    <td style={styles.td}>
                      {editing?.id === s.id ? (
                        <button style={{ ...styles.btn(), padding: "4px 10px", fontSize: 11 }} onClick={() => saveEdit(s.id)}>Kaydet</button>
                      ) : (
                        <button style={{ ...styles.btn("ghost"), padding: "4px 10px", fontSize: 11 }}
                          onClick={() => setEditing({ id: s.id, quantity: s.quantity })}>Düzenle</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>STOK EKLE</div>
          {["name", "unit", "quantity", "minLevel"].map((f, i) => (
            <div key={f} style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>
                {["MALZEMİ ADI", "BİRİM", "MİKTAR", "MİN. SEVİYE"][i]}
              </label>
              <input style={styles.input} value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })} />
            </div>
          ))}
          <button style={styles.btn()} onClick={addStock}>Ekle</button>
          <div style={{ marginTop: 20, borderTop: `1px solid ${C.border}`, paddingTop: 16 }}>
            <div style={{ fontSize: 12, color: C.gold, marginBottom: 8 }}>⚠ Düşük Stok Uyarıları</div>
            {stock.filter(s => s.quantity <= s.minLevel).map(s => (
              <div key={s.id} style={{ fontSize: 12, color: C.red, marginBottom: 4 }}>
                • {s.name}: {s.quantity} {s.unit} (min. {s.minLevel})
              </div>
            ))}
            {stock.filter(s => s.quantity <= s.minLevel).length === 0 && (
              <div style={{ fontSize: 12, color: C.green }}>✓ Tüm stoklar yeterli seviyede</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SalesReport({ orders }) {
  const completed = orders.filter(o => o.status === "tamamlandı");
  const todayTotal = completed.reduce((s, o) => s + o.total, 0);
  const itemCount = {};
  completed.forEach(o => o.items.forEach(i => { itemCount[i.name] = (itemCount[i.name] || 0) + i.qty; }));
  const topItems = Object.entries(itemCount).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const weekRevs = SALES_HISTORY.map(d => ({ val: d.revenue, label: d.date.slice(5) }));
  const maxRev = Math.max(...weekRevs.map(d => d.val));
  const hourly = HOURLY_DATA.map(h => ({ val: h.orders, label: h.hour }));
  const maxH = Math.max(...hourly.map(h => h.val));
  const weekTotal = SALES_HISTORY.reduce((s, d) => s + d.revenue, 0);

  return (
    <div>
      <div style={styles.pageTitle}>Satış Raporları</div>
      <div style={styles.pageSub}>Günlük · Haftalık · Aylık analiz</div>
      <div style={styles.grid4}>
        <StatCard icon="📅" label="BUGÜN GELİR" value={`₺${todayTotal.toLocaleString()}`} diff="+8% dün" />
        <StatCard icon="📆" label="HAFTALIK GELİR" value={`₺${weekTotal.toLocaleString()}`} diff="+15% geçen hafta" />
        <StatCard icon="🛍" label="BUGÜN SİPARİŞ" value={completed.length} diff={null} />
        <StatCard icon="💳" label="ORT. SEPET" value={`₺${completed.length ? Math.round(todayTotal / completed.length) : 0}`} diff={null} />
      </div>
      <div style={{ ...styles.grid2, marginTop: 20 }}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>HAFTALIK GELİR TRENDİ</div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 4, height: 100 }}>
            {weekRevs.map((d, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
                <div style={{ fontSize: 10, color: C.muted, marginBottom: 2 }}>₺{Math.round(d.val / 1000)}k</div>
                <div style={{ width: "100%", height: Math.round((d.val / maxRev) * 70) + 4, background: C.gold, borderRadius: "4px 4px 0 0", opacity: 0.8 }} />
                <div style={{ fontSize: 9, color: C.muted, marginTop: 3 }}>{d.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>EN ÇOK SATILAN ÜRÜNLER</div>
          {topItems.length > 0 ? topItems.map(([name, qty], i) => (
            <div key={name} style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, alignItems: "center" }}>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <span style={{ fontSize: 12, color: C.muted, width: 16 }}>{i + 1}.</span>
                <span style={{ fontSize: 13 }}>{name}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 60, height: 6, background: C.border, borderRadius: 3 }}>
                  <div style={{ width: `${(qty / topItems[0][1]) * 100}%`, height: "100%", background: C.gold, borderRadius: 3 }} />
                </div>
                <span style={{ fontSize: 12, color: C.gold, width: 20 }}>{qty}</span>
              </div>
            </div>
          )) : <div style={{ color: C.muted, fontSize: 13 }}>Henüz tamamlanan sipariş yok.</div>}
        </div>
      </div>
      <div style={{ ...styles.card, marginTop: 20 }}>
        <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>SAATLİK YOĞUNLUK (BUGÜN TAHMİN)</div>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 80 }}>
          {hourly.map((h, i) => (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div style={{ width: "100%", height: Math.round((h.val / maxH) * 65) + 4, background: C.blue, borderRadius: "3px 3px 0 0", opacity: 0.7 }} />
              <div style={{ fontSize: 9, color: C.muted, marginTop: 2 }}>{h.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function LoyaltySystem() {
  const [customers, setCustomers] = useState(LOYALTY_CUSTOMERS);
  const [form, setForm] = useState({ name: "", phone: "", birthday: "" });
  const [addPoints, setAddPoints] = useState({});

  const addCustomer = () => {
    if (!form.name || !form.phone) return;
    setCustomers(prev => [...prev, { id: Date.now(), ...form, points: 0, visits: 0 }]);
    setForm({ name: "", phone: "", birthday: "" });
  };

  const givePoints = (id) => {
    const pts = Number(addPoints[id] || 0);
    if (!pts) return;
    setCustomers(prev => prev.map(c => c.id === id ? { ...c, points: c.points + pts, visits: c.visits + 1 } : c));
    setAddPoints(prev => ({ ...prev, [id]: "" }));
  };

  return (
    <div>
      <div style={styles.pageTitle}>Müşteri Sadakat Sistemi</div>
      <div style={styles.pageSub}>Puan kazan · Kahve hediye · Özel kampanyalar</div>
      <div style={{ ...styles.card, marginBottom: 16, background: `${C.gold}12`, border: `1px solid ${C.gold}40` }}>
        <div style={{ fontSize: 13, color: C.gold }}>⭐ Kural: 5 kahve alana 1 kahve bedava · Her ₺1 = 1 puan · 100 puan = 1 kahve</div>
      </div>
      <div style={styles.grid2}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>MÜŞTERİLER</div>
          {customers.map(c => (
            <div key={c.id} style={{ borderBottom: `1px solid ${C.border}`, paddingBottom: 14, marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <div>
                  <div style={{ fontWeight: "bold", fontSize: 14 }}>{c.name}</div>
                  <div style={{ fontSize: 12, color: C.muted }}>{c.phone}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ color: C.gold, fontWeight: "bold", fontSize: 18 }}>{c.points} puan</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{c.visits} ziyaret</div>
                </div>
              </div>
              <div style={{ width: "100%", height: 6, background: C.border, borderRadius: 3, marginBottom: 8 }}>
                <div style={{ width: `${Math.min((c.points % 100) / 100 * 100, 100)}%`, height: "100%", background: C.gold, borderRadius: 3 }} />
              </div>
              <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>
                Sonraki ödüle {100 - (c.points % 100)} puan kaldı
                {c.birthday && ` · 🎂 ${c.birthday}`}
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <input style={{ ...styles.input, width: 80 }} type="number" placeholder="puan"
                  value={addPoints[c.id] || ""} onChange={e => setAddPoints({ ...addPoints, [c.id]: e.target.value })} />
                <button style={{ ...styles.btn(), padding: "6px 12px", fontSize: 12 }} onClick={() => givePoints(c.id)}>+ Puan</button>
              </div>
            </div>
          ))}
        </div>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>YENİ MÜŞTERİ KAYDI</div>
          {[["name", "AD SOYAD"], ["phone", "TELEFON"], ["birthday", "DOĞUM TARİHİ"]].map(([f, l]) => (
            <div key={f} style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>{l}</label>
              <input style={styles.input} type={f === "birthday" ? "date" : "text"}
                value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })} />
            </div>
          ))}
          <button style={styles.btn()} onClick={addCustomer}>Kaydet</button>
        </div>
      </div>
    </div>
  );
}

function ReservationSystem() {
  const [reservations, setReservations] = useState(RESERVATIONS_INIT);
  const [form, setForm] = useState({ name: "", date: "", time: "", people: "2", table: "Masa 1" });
  const tables = ["Masa 1", "Masa 2", "Masa 3", "Masa 4", "Masa 5", "Masa 6", "Masa 7", "Masa 8", "Bahçe 1", "Bahçe 2"];

  const add = () => {
    if (!form.name || !form.date || !form.time) return;
    setReservations(prev => [...prev, { id: Date.now(), ...form, status: "bekliyor" }]);
    setForm({ name: "", date: "", time: "", people: "2", table: "Masa 1" });
  };

  const updateRes = (id, status) => setReservations(prev => prev.map(r => r.id === id ? { ...r, status } : r));
  const removeRes = (id) => setReservations(prev => prev.filter(r => r.id !== id));
  const statusColor = { "onaylı": C.green, "bekliyor": C.gold, "iptal": C.red };

  return (
    <div>
      <div style={styles.pageTitle}>Rezervasyon Sistemi</div>
      <div style={styles.pageSub}>Masa rezervasyonu · Onay · Yönetim</div>
      <div style={styles.grid2}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>YENİ REZERVASYON</div>
          {[
            ["name", "AD SOYAD", "text"],
            ["date", "TARİH", "date"],
            ["time", "SAAT", "time"],
          ].map(([f, l, t]) => (
            <div key={f} style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>{l}</label>
              <input style={styles.input} type={t} value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })} />
            </div>
          ))}
          <div style={{ ...styles.grid2, gap: 10, marginBottom: 12 }}>
            <div>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>KİŞİ</label>
              <select style={styles.input} value={form.people} onChange={e => setForm({ ...form, people: e.target.value })}>
                {[1, 2, 3, 4, 5, 6, 7, 8].map(n => <option key={n}>{n}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>MASA</label>
              <select style={styles.input} value={form.table} onChange={e => setForm({ ...form, table: e.target.value })}>
                {tables.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <button style={styles.btn()} onClick={add}>Rezervasyon Oluştur</button>
        </div>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>REZERVASYONLAR</div>
          {reservations.map(r => (
            <div key={r.id} style={{ borderBottom: `1px solid ${C.border}`, paddingBottom: 12, marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontWeight: "bold" }}>{r.name}</span>
                <span style={styles.badge(statusColor[r.status])}>{r.status}</span>
              </div>
              <div style={{ fontSize: 12, color: C.muted, marginBottom: 8 }}>
                📅 {r.date} · ⏰ {r.time} · 👥 {r.people} kişi · {r.table}
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                {r.status === "bekliyor" && (
                  <button style={{ ...styles.btn(), padding: "4px 10px", fontSize: 11 }} onClick={() => updateRes(r.id, "onaylı")}>Onayla</button>
                )}
                <button style={{ ...styles.btn("danger"), padding: "4px 10px", fontSize: 11 }} onClick={() => removeRes(r.id)}>Sil</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StaffSystem() {
  const [staff, setStaff] = useState(STAFF_INIT);
  const [form, setForm] = useState({ name: "", role: "Barista", shift: "", salary: "" });
  const roles = ["Barista", "Garson", "Kasiyer", "Şef", "Temizlik"];
  const statusColor = { aktif: C.green, izinli: C.gold, pasif: C.red };

  const addStaff = () => {
    if (!form.name || !form.shift) return;
    setStaff(prev => [...prev, { id: Date.now(), ...form, status: "aktif", salary: Number(form.salary) }]);
    setForm({ name: "", role: "Barista", shift: "", salary: "" });
  };

  const toggleStatus = (id) => setStaff(prev => prev.map(s => s.id === id ? { ...s, status: s.status === "aktif" ? "izinli" : "aktif" } : s));

  return (
    <div>
      <div style={styles.pageTitle}>Personel Takip</div>
      <div style={styles.pageSub}>Vardiya · Görev · Performans</div>
      <div style={styles.grid2}>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>PERSONEL</div>
          <table style={styles.table}>
            <thead><tr>
              <th style={styles.th}>AD</th><th style={styles.th}>GÖREV</th>
              <th style={styles.th}>VARDİYA</th><th style={styles.th}>MAAŞ</th>
              <th style={styles.th}>DURUM</th><th style={styles.th}></th>
            </tr></thead>
            <tbody>
              {staff.map(s => (
                <tr key={s.id}>
                  <td style={styles.td}>{s.name}</td>
                  <td style={styles.td}>{s.role}</td>
                  <td style={styles.td}>{s.shift}</td>
                  <td style={styles.td}>₺{s.salary?.toLocaleString()}</td>
                  <td style={styles.td}><span style={styles.badge(statusColor[s.status])}>{s.status}</span></td>
                  <td style={styles.td}>
                    <button style={{ ...styles.btn("ghost"), padding: "3px 10px", fontSize: 11 }} onClick={() => toggleStatus(s.id)}>
                      {s.status === "aktif" ? "İzne Al" : "Aktif Et"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={styles.card}>
          <div style={{ fontSize: 13, color: C.muted, marginBottom: 14, letterSpacing: 1 }}>PERSONEL EKLE</div>
          {[["name", "AD SOYAD"], ["shift", "VARDİYA (ör. 08:00-16:00)"], ["salary", "MAAŞ (₺)"]].map(([f, l]) => (
            <div key={f} style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>{l}</label>
              <input style={styles.input} value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })} />
            </div>
          ))}
          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 11, color: C.muted, display: "block", marginBottom: 4 }}>GÖREV</label>
            <select style={styles.input} value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
              {roles.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <button style={styles.btn()} onClick={addStaff}>Ekle</button>
          <div style={{ marginTop: 20, borderTop: `1px solid ${C.border}`, paddingTop: 16 }}>
            <div style={{ fontSize: 12, color: C.muted, marginBottom: 8, letterSpacing: 1 }}>ÖZET</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[
                ["Aktif", staff.filter(s => s.status === "aktif").length],
                ["İzinli", staff.filter(s => s.status === "izinli").length],
                ["Toplam Maaş", `₺${staff.reduce((s, e) => s + (e.salary || 0), 0).toLocaleString()}`],
                ["Toplam Personel", staff.length],
              ].map(([label, val]) => (
                <div key={label} style={{ ...styles.card, padding: "12px 14px" }}>
                  <div style={{ fontSize: 18, fontWeight: "bold", color: C.gold }}>{val}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function WebsitePage({ menu }) {
  return (
    <div>
      <div style={styles.pageTitle}>Kafe Web Sitesi</div>
      <div style={styles.pageSub}>Önizleme · Müşterilerin göreceği sayfa</div>
      <div style={{ ...styles.card, background: "#0a0908", padding: 0, overflow: "hidden", borderRadius: 12 }}>
        {/* Hero */}
        <div style={{ background: `linear-gradient(135deg, #1a1208 0%, #2a1e0a 100%)`, padding: "60px 48px", textAlign: "center", borderBottom: `1px solid ${C.border}` }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>☕</div>
          <div style={{ fontSize: 36, fontWeight: "bold", color: C.gold, fontFamily: "'Georgia', serif", letterSpacing: 4 }}>KAFE SİSTEM</div>
          <div style={{ fontSize: 14, color: C.muted, marginTop: 8, letterSpacing: 3 }}>LEZZET · KALİTE · ATMOSFER</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 16, marginTop: 24 }}>
            <div style={{ ...styles.btn(), padding: "12px 28px" }}>Rezervasyon</div>
            <div style={{ ...styles.btn("ghost"), padding: "12px 28px", border: `1px solid ${C.gold}`, borderRadius: 5 }}>Menüyü Gör</div>
          </div>
        </div>
        {/* Menü Önizleme */}
        <div style={{ padding: "32px 48px" }}>
          <div style={{ textAlign: "center", marginBottom: 24 }}>
            <div style={{ fontSize: 11, color: C.muted, letterSpacing: 3 }}>MENÜMÜZ</div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
            {menu.slice(0, 6).map(item => (
              <div key={item.id} style={{ ...styles.card, textAlign: "center" }}>
                <div style={{ fontSize: 28 }}>{item.photo}</div>
                <div style={{ fontSize: 14, fontWeight: "bold", margin: "8px 0 4px" }}>{item.name}</div>
                <div style={{ fontSize: 12, color: C.muted }}>{item.desc}</div>
                <div style={{ fontSize: 16, color: C.gold, fontWeight: "bold", marginTop: 8 }}>₺{item.price}</div>
                {item.campaign && <div style={{ ...styles.tag, marginTop: 6 }}>🏷 {item.campaign}</div>}
              </div>
            ))}
          </div>
        </div>
        {/* İletişim & Konum */}
        <div style={{ borderTop: `1px solid ${C.border}`, padding: "28px 48px", display: "flex", justifyContent: "space-around" }}>
          {[
            { icon: "📍", title: "Adres", val: "Bağcılar Cad. No:12, İstanbul" },
            { icon: "📞", title: "Telefon", val: "0212 555 1234" },
            { icon: "🕐", title: "Çalışma Saatleri", val: "08:00 – 22:00" },
            { icon: "📱", title: "Instagram", val: "@kafesistem" },
          ].map(i => (
            <div key={i.title} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 24 }}>{i.icon}</div>
              <div style={{ fontSize: 11, color: C.muted, marginTop: 4, letterSpacing: 1 }}>{i.title}</div>
              <div style={{ fontSize: 13, marginTop: 4 }}>{i.val}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── ANA UYGULAMA ─────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", icon: "📊", label: "Genel Bakış" },
  { id: "menu", icon: "🍽", label: "Dijital Menü" },
  { id: "orders", icon: "🧾", label: "Sipariş Takip" },
  { id: "stock", icon: "📦", label: "Stok Takip" },
  { id: "sales", icon: "📈", label: "Satış Raporu" },
  { id: "loyalty", icon: "⭐", label: "Sadakat Sistemi" },
  { id: "reservations", icon: "📅", label: "Rezervasyon" },
  { id: "staff", icon: "👥", label: "Personel" },
  { id: "website", icon: "🌐", label: "Web Sitesi" },
];

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [menu, setMenu] = useState(INITIAL_MENU);
  const [stock, setStock] = useState(INITIAL_STOCK);
  const [orders, setOrders] = useState([
    { id: 1, table: "Masa 3", items: [{ id: 2, name: "Latte", photo: "🥛", price: 65, qty: 2 }], total: 130, status: "hazırlanıyor", time: "10:15" },
    { id: 2, table: "Masa 7", items: [{ id: 4, name: "Cheesecake", photo: "🍰", price: 75, qty: 1 }, { id: 1, name: "Espresso", photo: "☕", price: 45, qty: 1 }], total: 120, status: "bekliyor", time: "10:22" },
    { id: 3, table: "Masa 1", items: [{ id: 6, name: "Limonata", photo: "🍋", price: 50, qty: 3 }], total: 150, status: "tamamlandı", time: "09:45" },
  ]);

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <Dashboard orders={orders} menu={menu} />;
      case "menu": return <DigitalMenu menu={menu} setMenu={setMenu} />;
      case "orders": return <OrderSystem orders={orders} setOrders={setOrders} menu={menu} />;
      case "stock": return <StockSystem stock={stock} setStock={setStock} />;
      case "sales": return <SalesReport orders={orders} />;
      case "loyalty": return <LoyaltySystem />;
      case "reservations": return <ReservationSystem />;
      case "staff": return <StaffSystem />;
      case "website": return <WebsitePage menu={menu} />;
      default: return null;
    }
  };

  return (
    <div style={styles.app}>
      <div style={styles.sidebar}>
        <div style={styles.logo}>
          <div style={styles.logoMain}>KAFÉ</div>
          <div style={styles.logoSub}>YÖNETİM SİSTEMİ</div>
        </div>
        <nav style={styles.nav}>
          {NAV.map(n => (
            <div key={n.id} style={styles.navItem(page === n.id)} onClick={() => setPage(n.id)}>
              <span>{n.icon}</span>
              <span>{n.label}</span>
            </div>
          ))}
        </nav>
        <div style={{ padding: "16px 20px", borderTop: `1px solid ${C.border}`, fontSize: 11, color: C.muted }}>
          v1.0 · 2026
        </div>
      </div>
      <div style={styles.main}>
        {renderPage()}
      </div>
    </div>
  );
}
